package codigos;

public class TesteCalculadora {
	public static void main(String[] args) {
		
		Calculadora calc = new Calculadora();
		
		int x = 5;
		int y = 5;
		
		double resultado = calc.somar(x,y);
		
		if(resultado == 10) {
			System.out.println("Valor Correto!!!");
		}else {
			System.out.println("Valor Errado");
		}

	}
}
