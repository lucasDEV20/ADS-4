package testes;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import codigos.Calculadora;

class CalculadoraTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		//System.out.println("Comandos executado antes de todos os Teste");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		//System.out.println("Comandos executado depois de todos os Teste");
	}

	@BeforeEach
	void setUp() throws Exception {
		//System.out.println("Comandos executado antes de cada Teste");
	}

	@AfterEach
	void tearDown() throws Exception {
		//System.out.println("Comandos executado depois de cada Teste");
	}

	@Test
	void testSomar() {
		System.out.println("Teste: somar");
		int n1 = 5;
		int n2 = 5;
		Calculadora c = new Calculadora();
		double expResult = 10.0;
		double result = c.somar(n1, n2);
		assertEquals(expResult, result, 0);
	}

	@Test
	void testSubtrair() {
		System.out.println("Teste: subtrair");
		int n1 = 5;
		int n2 = 3;
		Calculadora c = new Calculadora();
		double expResult = 2.0;
		double result = c.subtrair(n1, n2);
		assertEquals(expResult, result, 0);
	}

	@Test
	public void testMultiplicar() {
		System.out.println("Teste: multiplicar");
		int n1 = 2;
		int n2 = 3;
		Calculadora c = new Calculadora();
		double expResult = 6;
		double result = c.multiplicar(n1, n2);
		assertEquals(expResult, result, 0);
	}

	@Test
	public void testDividir() {
		System.out.println("Teste: dividir");
		int n1 = 5;
		int n2 = 2;
		Calculadora c = new Calculadora();
		double expResult = 2.5;
		double result = c.dividir(n1, n2);
		assertEquals(expResult, result, 0);
	}

}
